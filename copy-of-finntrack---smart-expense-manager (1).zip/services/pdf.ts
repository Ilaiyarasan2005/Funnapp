
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Transaction, TransactionType } from '../types';

interface ReportConfig {
  userName: string;
  startDate: string;
  endDate: string;
  lang: 'en' | 'ta';
}

export const PdfService = {
  generateReport: (transactions: Transaction[], config: ReportConfig) => {
    const doc = new jsPDF();
    const { userName, startDate, endDate } = config;

    // Financial calculations
    const income = transactions
      .filter(t => t.type === TransactionType.INCOME)
      .reduce((sum, t) => sum + t.amount, 0);
    const expense = transactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .reduce((sum, t) => sum + t.amount, 0);
    const savings = income - expense;

    // Category summary
    const categoryTotals: Record<string, number> = {};
    transactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .forEach(t => {
        categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
      });

    const categoryRows = Object.entries(categoryTotals)
      .sort((a, b) => b[1] - a[1])
      .map(([cat, amt]) => [cat, `Rs. ${amt.toLocaleString()}`, `${((amt / expense) * 100).toFixed(1)}%`]);

    // Header
    doc.setFillColor(37, 99, 235); // Blue-600
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('FINNTRACK', 15, 20);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('PERSONAL FINANCIAL REPORT', 15, 28);

    doc.setFontSize(12);
    doc.text(`Report for: ${userName || 'Valued User'}`, 195, 20, { align: 'right' });
    doc.text(`Period: ${startDate} to ${endDate}`, 195, 28, { align: 'right' });

    // Summary Section
    doc.setTextColor(50, 50, 50);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Executive Summary', 15, 55);

    autoTable(doc, {
      startY: 60,
      head: [['Metric', 'Amount']],
      body: [
        ['Total Income', `Rs. ${income.toLocaleString()}`],
        ['Total Expenses', `Rs. ${expense.toLocaleString()}`],
        ['Net Savings', `Rs. ${savings.toLocaleString()}`]
      ],
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235] },
      columnStyles: { 1: { halign: 'right', fontStyle: 'bold' } }
    });

    // Category Section
    const summaryEndY = (autoTable as any).previousCursor ? (autoTable as any).previousCursor.y : 80;
    doc.text('Expense by Category', 15, summaryEndY + 15);

    autoTable(doc, {
      startY: summaryEndY + 20,
      head: [['Category', 'Amount', 'Share']],
      body: categoryRows.length > 0 ? categoryRows : [['No expenses found', '-', '-']],
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 229] } // Indigo-600
    });

    // Detailed Log
    doc.addPage();
    doc.setFillColor(37, 99, 235);
    doc.rect(0, 0, 210, 20, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.text('Detailed Transaction Log', 15, 13);

    const sortedTransactions = [...transactions].sort((a, b) => b.date.localeCompare(a.date));
    const detailedRows = sortedTransactions.map(t => [
      t.date,
      t.type.toUpperCase(),
      t.category,
      t.note || '-',
      `Rs. ${t.amount.toLocaleString()}`
    ]);

    autoTable(doc, {
      startY: 25,
      head: [['Date', 'Type', 'Category', 'Description', 'Amount']],
      body: detailedRows,
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235] },
      columnStyles: { 4: { halign: 'right' } }
    });

    // Footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(
        `Generated on ${new Date().toLocaleString()} | Page ${i} of ${pageCount}`,
        105,
        285,
        { align: 'center' }
      );
    }

    return doc;
  }
};
