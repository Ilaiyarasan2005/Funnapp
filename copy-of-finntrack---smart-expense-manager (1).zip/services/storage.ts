
import { Transaction, Language } from '../types';

const STORAGE_KEYS = {
  TRANSACTIONS: 'finntrack_transactions',
  LANGUAGE: 'finntrack_lang',
  BIOMETRIC_ENABLED: 'finntrack_biometric_enabled',
  SAVED_USER: 'finntrack_saved_user',
  REMINDER_ENABLED: 'finntrack_reminder_enabled',
  REMINDER_TIME: 'finntrack_reminder_time',
  LAST_REMINDER_DATE: 'finntrack_last_reminder_date',
  ACTIVE_SESSION: 'finntrack_active_session' // Key for persisting login
};

export const StorageService = {
  saveTransactions: (data: Transaction[]) => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data));
  },
  getTransactions: (): Transaction[] => {
    const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    return data ? JSON.parse(data) : [];
  },
  saveLanguage: (lang: Language) => {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  },
  getLanguage: (): Language => {
    return (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language) || 'en';
  },
  setBiometricEnabled: (enabled: boolean) => {
    localStorage.setItem(STORAGE_KEYS.BIOMETRIC_ENABLED, JSON.stringify(enabled));
  },
  getBiometricEnabled: (): boolean => {
    const data = localStorage.getItem(STORAGE_KEYS.BIOMETRIC_ENABLED);
    return data ? JSON.parse(data) : false;
  },
  saveUserForBiometric: (username: string | null) => {
    if (username) localStorage.setItem(STORAGE_KEYS.SAVED_USER, username);
    else localStorage.removeItem(STORAGE_KEYS.SAVED_USER);
  },
  getSavedUser: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.SAVED_USER);
  },
  setReminderEnabled: (enabled: boolean) => {
    localStorage.setItem(STORAGE_KEYS.REMINDER_ENABLED, JSON.stringify(enabled));
  },
  getReminderEnabled: (): boolean => {
    const data = localStorage.getItem(STORAGE_KEYS.REMINDER_ENABLED);
    return data ? JSON.parse(data) : false;
  },
  setReminderTime: (time: string) => {
    localStorage.setItem(STORAGE_KEYS.REMINDER_TIME, time);
  },
  getReminderTime: (): string => {
    return localStorage.getItem(STORAGE_KEYS.REMINDER_TIME) || '20:00';
  },
  setLastReminderDate: (date: string) => {
    localStorage.setItem(STORAGE_KEYS.LAST_REMINDER_DATE, date);
  },
  getLastReminderDate: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.LAST_REMINDER_DATE);
  },
  // Session methods
  saveActiveSession: (userId: string) => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_SESSION, userId);
  },
  getActiveSession: (): string | null => {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_SESSION);
  },
  clearActiveSession: () => {
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_SESSION);
  }
};
