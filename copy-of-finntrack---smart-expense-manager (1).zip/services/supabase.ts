
import { createClient } from '@supabase/supabase-js';
import { Transaction } from '../types';

/**
 * SQL SCHEMA:
 * 
 * CREATE TABLE profiles (user_id TEXT PRIMARY KEY, full_name TEXT NOT NULL, mobile TEXT, email TEXT, password TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW());
 * CREATE TABLE transactions (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id TEXT NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE, amount NUMERIC NOT NULL, category TEXT NOT NULL, date DATE NOT NULL, time TIME NOT NULL DEFAULT CURRENT_TIME, note TEXT, type TEXT NOT NULL CHECK (type IN ('income', 'expense')), created_at TIMESTAMPTZ DEFAULT NOW());
 * CREATE INDEX idx_tr_user_date ON transactions(user_id, date DESC, time DESC);
 * ALTER TABLE profiles ENABLE ROW LEVEL SECURITY; ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
 * CREATE POLICY "Public access" ON profiles FOR ALL USING (true) WITH CHECK (true);
 * CREATE POLICY "Public access" ON transactions FOR ALL USING (true) WITH CHECK (true);
 */

const supabaseUrl = 'https://fhxqllbbfcajvweoirqf.supabase.co';
const supabaseAnonKey = 'sb_publishable_xfZkq1Dyk6dJWR8-P0SdMg_FqRIeADG';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const SupabaseService = {
  async registerUser(data: { userId: string, fullName: string, mobile: string, email: string, password: string }) {
    try {
      const { error } = await supabase.from('profiles').insert({
        user_id: data.userId,
        full_name: data.fullName,
        mobile: data.mobile,
        email: data.email,
        password: data.password
      });
      return { data: !error, error: error?.message || null };
    } catch (err) {
      return { data: false, error: 'Registration failed' };
    }
  },

  async loginUser(userId: string, password: string) {
    try {
      const { data, error } = await supabase.from('profiles').select('user_id, password').eq('user_id', userId).single();
      if (error || !data) return { data: null, error: 'User not found' };
      if (data.password !== password) return { data: null, error: 'Invalid password' };
      return { data: data.user_id, error: null };
    } catch (err) {
      return { data: null, error: 'Login failed' };
    }
  },

  async verifyIdentity(userId: string, mobile: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('user_id', userId)
        .eq('mobile', mobile)
        .single();
      
      if (error || !data) return { data: false, error: 'User not found with these details' };
      return { data: true, error: null };
    } catch (err) {
      return { data: false, error: 'Verification failed' };
    }
  },

  async updatePassword(userId: string, newPassword: string) {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ password: newPassword })
        .eq('user_id', userId);
      
      if (error) return { data: false, error: error.message };
      return { data: true, error: null };
    } catch (err) {
      return { data: false, error: 'Update failed' };
    }
  },

  async fetchTransactions(userId: string) {
    try {
      const { data, error } = await supabase.from('transactions').select('*').eq('user_id', userId).order('date', { ascending: false }).order('time', { ascending: false });
      return { data: data as Transaction[], error: error?.message || null };
    } catch (err) {
      return { data: null, error: 'Fetch failed' };
    }
  },

  async upsertTransaction(userId: string, transaction: Transaction) {
    try {
      const { error } = await supabase.from('transactions').upsert({ 
        id: transaction.id, user_id: userId, amount: transaction.amount, category: transaction.category,
        date: transaction.date, time: transaction.time, note: transaction.note, type: transaction.type
      });
      return { data: !error, error: error?.message || null };
    } catch (err) {
      return { data: false, error: 'Sync failed' };
    }
  },

  async bulkUpsert(userId: string, transactions: Transaction[]) {
    if (transactions.length === 0) return { data: true, error: null };
    try {
      const payload = transactions.map(t => ({
        id: t.id, user_id: userId, amount: t.amount, category: t.category,
        date: t.date, time: t.time || '00:00:00', note: t.note, type: t.type
      }));
      const { error } = await supabase.from('transactions').upsert(payload);
      return { data: !error, error: error?.message || null };
    } catch (err) {
      return { data: false, error: 'Bulk sync failed' };
    }
  },

  async deleteTransaction(id: string) {
    try {
      const { error } = await supabase.from('transactions').delete().eq('id', id);
      return { data: !error, error: error?.message || null };
    } catch (err) {
      return { data: false, error: 'Delete failed' };
    }
  }
};
