
import { GoogleGenAI } from "@google/genai";
import { Transaction, ChatMessage } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialAdvice = async (transactions: Transaction[], lang: 'en' | 'ta') => {
  try {
    const recent = transactions.slice(-20);
    const summary = recent.map(t => `${t.date} | ${t.type}: ${t.amount} (${t.category}) | Note: ${t.note}`).join('\n');

    const prompt = `
      Act as a friendly professional financial advisor for a user in ${lang === 'ta' ? 'Tamil Nadu, India' : 'the world'}.
      Today is ${new Date().toISOString().split('T')[0]}.
      Here are their recent personal transactions:
      ${summary}
      
      Give a short (2-3 sentence) helpful advice on how they can save money or manage their budget better.
      Output ONLY in ${lang === 'ta' ? 'Tamil' : 'English'}.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text || (lang === 'ta' ? 'ஆலோசனை கிடைக்கவில்லை.' : 'No advice available right now.');
  } catch (error) {
    console.error("AI Error:", error);
    return lang === 'ta' ? 'மன்னிக்கவும், AI தற்போது கிடைக்கவில்லை.' : 'Sorry, AI insights are currently unavailable.';
  }
};

export const chatWithAI = async (
  query: string, 
  transactions: Transaction[], 
  chatHistory: ChatMessage[], 
  lang: 'en' | 'ta'
) => {
  try {
    const dataSummary = transactions.map(t => `${t.date} | ${t.type}: ${t.amount} (${t.category}) | ${t.note}`).join('\n');
    
    const historyContext = chatHistory.map(msg => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`).join('\n');

    const systemInstruction = `
      You are an AI financial assistant for FinnTrack. 
      You have access to the user's transaction history below.
      Today is ${new Date().toISOString().split('T')[0]}.
      
      User Data:
      ${dataSummary}
      
      Instructions:
      1. Answer user questions specifically using the data provided.
      2. If asked about totals (e.g., "How much did I spend on food?"), calculate it from the list.
      3. Identify trends, highest spending categories, or unusual expenses if asked.
      4. Respond in simple, friendly, and concise language.
      5. Respond strictly in ${lang === 'ta' ? 'Tamil' : 'English'}.
      6. Do not mention technical details like Supabase or database IDs.
      7. If no transactions exist for a specific query, politely inform the user.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `History:\n${historyContext}\n\nUser Question: ${query}`,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return response.text || (lang === 'ta' ? 'பதில் கிடைக்கவில்லை.' : 'I couldn\'t process that request.');
  } catch (error) {
    console.error("Chat AI Error:", error);
    return lang === 'ta' ? 'மன்னிக்கவும், தகவல் தொடர்பில் சிக்கல் உள்ளது.' : 'Sorry, I encountered an error communicating with the AI.';
  }
};
