
import React, { useState, useEffect, useRef } from 'react';
import { Transaction, Language, TransactionType } from './types';
import { translations } from './translations';
import { StorageService } from './services/storage';
import { SupabaseService } from './services/supabase';
import { getFinancialAdvice } from './services/gemini';
import { Dashboard } from './components/Dashboard';
import { History } from './components/History';
import { TransactionForm } from './components/TransactionForm';
import { Login } from './components/Login';
import { ExportModal } from './components/ExportModal';
import { AIAssistant } from './components/AIAssistant';
import { 
  Plus, 
  History as HistoryIcon, 
  LayoutDashboard, 
  Settings, 
  Sparkles,
  RefreshCw,
  LogOut,
  Fingerprint,
  ToggleLeft as ToggleOff,
  ToggleRight as ToggleOn,
  AlertCircle,
  Bell,
  Clock,
  Loader2,
  CloudUpload,
  User,
  MessageSquare
} from 'lucide-react';

const App: React.FC = () => {
  // Initialize state from StorageService to maintain session after refresh
  const [isAuthenticated, setIsAuthenticated] = useState(() => !!StorageService.getActiveSession());
  const [userIdentifier, setUserIdentifier] = useState(() => StorageService.getActiveSession() || '');
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [lang, setLang] = useState<Language>('en');
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history' | 'ai' | 'settings'>('dashboard');
  const [advice, setAdvice] = useState<string>('');
  const [loadingAdvice, setLoadingAdvice] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isBiometricEnabled, setIsBiometricEnabled] = useState(false);
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isReminderEnabled, setIsReminderEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState('20:00');
  const [isInitialLoading, setIsInitialLoading] = useState(false);

  const t = translations[lang];

  useEffect(() => {
    setLang(StorageService.getLanguage());
    setIsBiometricEnabled(StorageService.getBiometricEnabled());
    setIsReminderEnabled(StorageService.getReminderEnabled());
    setReminderTime(StorageService.getReminderTime());
    
    const checkSupport = async () => {
      const isSupported = !!(window.PublicKeyCredential && await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable());
      setIsBiometricSupported(isSupported);
    };
    checkSupport();
  }, []);

  useEffect(() => {
    if (isAuthenticated && userIdentifier) {
      const loadCloudData = async () => {
        setIsInitialLoading(true);
        setIsSyncing(true);
        try {
          const { data: cloudData, error } = await SupabaseService.fetchTransactions(userIdentifier);
          const localData = StorageService.getTransactions();
          
          if (error) throw new Error(error);

          const mergedMap = new Map<string, Transaction>();
          localData.forEach(tr => mergedMap.set(tr.id, tr));
          cloudData?.forEach(tr => mergedMap.set(tr.id, tr));
          
          const mergedList = Array.from(mergedMap.values()).sort((a, b) => b.date.localeCompare(a.date));
          
          setTransactions(mergedList);
          StorageService.saveTransactions(mergedList);

          const localOnly = localData.filter(l => !cloudData?.find(c => c.id === l.id));
          if (localOnly.length > 0) {
            await SupabaseService.bulkUpsert(userIdentifier, localOnly);
          }
        } catch (err) {
          setTransactions(StorageService.getTransactions());
        } finally {
          setIsInitialLoading(false);
          setIsSyncing(false);
        }
      };
      loadCloudData();
    }
  }, [isAuthenticated, userIdentifier]);

  useEffect(() => {
    if (transactions.length > 0 || userIdentifier) {
      StorageService.saveTransactions(transactions);
    }
  }, [transactions]);

  const handleSaveTransaction = async (data: Omit<Transaction, 'id'>, id?: string) => {
    setIsSyncing(true);
    const newId = id || crypto.randomUUID();
    const transaction: Transaction = { ...data, id: newId };
    
    if (id) {
      setTransactions(prev => prev.map(tr => tr.id === id ? transaction : tr));
    } else {
      setTransactions(prev => [transaction, ...prev]);
    }

    await SupabaseService.upsertTransaction(userIdentifier, transaction);
    setIsSyncing(false);
    setShowForm(false);
    setEditingTransaction(null);
  };

  const handleDeleteTransaction = async (id: string) => {
    setIsSyncing(true);
    setTransactions(prev => prev.filter(t => t.id !== id));
    await SupabaseService.deleteTransaction(id);
    setIsSyncing(false);
  };

  const fetchAdvice = async () => {
    setLoadingAdvice(true);
    const result = await getFinancialAdvice(transactions, lang);
    setAdvice(result);
    setLoadingAdvice(false);
  };

  const handleLogin = (identifier: string) => {
    StorageService.saveActiveSession(identifier); // Save session on login
    setUserIdentifier(identifier);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    StorageService.clearActiveSession(); // Clear session on logout
    setIsAuthenticated(false);
    setUserIdentifier('');
    window.location.reload();
  };

  if (!isAuthenticated) return <Login onLogin={handleLogin} lang={lang} setLang={setLang} />;

  if (isInitialLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <Loader2 size={48} className="text-blue-600 animate-spin mb-4" />
        <h2 className="text-xl font-bold text-gray-800">FinnTrack Cloud Sync</h2>
        <p className="text-gray-500">Restoring your data...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto min-h-screen pb-24 relative bg-gray-50">
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg">
            <RefreshCw size={20} />
          </div>
          <h1 className="text-xl font-bold">{t.appTitle}</h1>
        </div>
        <div className={`flex items-center gap-1.5 text-[10px] font-black uppercase text-blue-600 transition-opacity ${isSyncing ? 'opacity-100' : 'opacity-0'}`}>
          <CloudUpload size={12} className="animate-pulse" />
          <span>{t.syncStatus}</span>
        </div>
      </header>

      <main className="p-6">
        {activeTab === 'dashboard' && (
          <div className="mb-6 bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-3xl text-white shadow-xl relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={18} className="text-yellow-300" />
                <h4 className="font-bold text-sm uppercase opacity-90">{t.smartAdvice}</h4>
              </div>
              {loadingAdvice ? (
                <div className="flex items-center gap-3 py-2 animate-pulse">
                  <Loader2 size={24} className="animate-spin text-white" />
                  <p className="text-lg font-bold">Thinking...</p>
                </div>
              ) : (
                <>
                  <p className="text-lg font-medium leading-relaxed">
                    {advice || (lang === 'ta' ? 'ஆலோசனையைப் பெற கிளிக் செய்யவும்.' : 'Click to get AI insights on your spending.')}
                  </p>
                  {!advice && (
                    <button onClick={fetchAdvice} className="mt-4 px-4 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-xl text-sm font-bold transition-all">
                      Analyze Now
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <Dashboard transactions={transactions} lang={lang} onExportClick={() => setIsExportModalOpen(true)} />
        )}
        
        {activeTab === 'history' && (
          <History 
            transactions={transactions} 
            onDelete={handleDeleteTransaction} 
            onEdit={(tr) => { setEditingTransaction(tr); setShowForm(true); }} 
            lang={lang} 
            onExportClick={() => setIsExportModalOpen(true)} 
          />
        )}

        {activeTab === 'ai' && <AIAssistant transactions={transactions} lang={lang} />}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-500"><User size={20} /></div>
                <div>
                  <p className="font-bold">{userIdentifier}</p>
                  <p className="text-[10px] text-green-500 font-bold">SECURED CLOUD</p>
                </div>
              </div>
              <button onClick={handleLogout} className="text-red-500 p-2"><LogOut size={20} /></button>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-50 font-bold flex items-center gap-2"><Settings size={18} /> {t.settings}</div>
              <div className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-50 text-blue-600 rounded-xl"><Bell size={18} /></div>
                    <p className="font-bold text-sm">{t.dailyReminder}</p>
                  </div>
                  <button onClick={() => { setIsReminderEnabled(!isReminderEnabled); StorageService.setReminderEnabled(!isReminderEnabled); }}>
                    {isReminderEnabled ? <ToggleOn size={32} className="text-blue-600" /> : <ToggleOff size={32} className="text-gray-300" />}
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-50 text-purple-600 rounded-xl"><Fingerprint size={18} /></div>
                    <p className="font-bold text-sm">{t.biometricLogin}</p>
                  </div>
                  {isBiometricSupported ? (
                    <button onClick={() => { setIsBiometricEnabled(!isBiometricEnabled); StorageService.setBiometricEnabled(!isBiometricEnabled); }}>
                      {isBiometricEnabled ? <ToggleOn size={32} className="text-blue-600" /> : <ToggleOff size={32} className="text-gray-300" />}
                    </button>
                  ) : <span className="text-[10px] font-bold text-gray-400">Not Supported</span>}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 p-2 grid grid-cols-2 gap-2">
              <button onClick={() => { setLang('en'); StorageService.saveLanguage('en'); }} className={`py-3 rounded-xl font-bold transition-all ${lang === 'en' ? 'bg-blue-600 text-white' : 'text-gray-500'}`}>English</button>
              <button onClick={() => { setLang('ta'); StorageService.saveLanguage('ta'); }} className={`py-3 rounded-xl font-bold transition-all ${lang === 'ta' ? 'bg-blue-600 text-white font-tamil' : 'text-gray-500'}`}>தமிழ்</button>
            </div>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 py-4 flex items-center justify-between z-50 shadow-lg">
        <button onClick={() => setActiveTab('dashboard')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'dashboard' ? 'text-blue-600 scale-110' : 'text-gray-400'}`}>
          <LayoutDashboard size={22} /><span className="text-[9px] font-bold uppercase">{t.dashboard}</span>
        </button>
        <button onClick={() => setActiveTab('history')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'history' ? 'text-blue-600 scale-110' : 'text-gray-400'}`}>
          <HistoryIcon size={22} /><span className="text-[9px] font-bold uppercase">{t.history}</span>
        </button>
        <div className="flex-1 flex justify-center -mt-10">
          <button onClick={() => { setEditingTransaction(null); setShowForm(true); }} className="w-14 h-14 bg-blue-600 text-white rounded-full shadow-xl flex items-center justify-center hover:bg-blue-700 active:scale-90 transition-all ring-8 ring-white">
            <Plus size={32} />
          </button>
        </div>
        <button onClick={() => setActiveTab('ai')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'ai' ? 'text-blue-600 scale-110' : 'text-gray-400'}`}>
          <MessageSquare size={22} /><span className="text-[9px] font-bold uppercase">{t.aiAssistant}</span>
        </button>
        <button onClick={() => setActiveTab('settings')} className={`flex-1 flex flex-col items-center gap-1 ${activeTab === 'settings' ? 'text-blue-600 scale-110' : 'text-gray-400'}`}>
          <Settings size={22} /><span className="text-[9px] font-bold uppercase">{t.settings}</span>
        </button>
      </nav>

      {showForm && <TransactionForm lang={lang} initialData={editingTransaction || undefined} onCancel={() => { setShowForm(false); setEditingTransaction(null); }} onSave={handleSaveTransaction} />}
      {isExportModalOpen && <ExportModal lang={lang} transactions={transactions} userName={userIdentifier} onClose={() => setIsExportModalOpen(false)} />}
    </div>
  );
};

export default App;
