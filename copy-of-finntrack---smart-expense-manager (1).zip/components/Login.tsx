
import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  RefreshCw, 
  Lock, 
  Eye, 
  EyeOff, 
  Fingerprint, 
  Loader2, 
  Sparkles, 
  Hash, 
  User, 
  Smartphone, 
  Mail,
  ArrowLeft,
  CheckCircle2,
  Copy,
  ShieldCheck,
  KeyRound
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { StorageService } from '../services/storage';
import { SupabaseService } from '../services/supabase';

interface InputFieldProps {
  name: string;
  type: string;
  placeholder: string;
  icon: any;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  showPassword?: boolean;
  onTogglePassword?: () => void;
  disabled: boolean;
  required?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({ 
  name, 
  type, 
  placeholder, 
  icon: Icon, 
  value, 
  onChange, 
  showPassword, 
  onTogglePassword, 
  disabled, 
  required = true 
}) => (
  <div className="relative group animate-in slide-in-from-left-4 duration-300 fill-mode-both">
    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 group-focus-within:scale-110 transition-all">
      <Icon size={18} />
    </div>
    <input
      type={type === 'password' && showPassword ? 'text' : type}
      name={name}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      required={required}
      disabled={disabled}
      className="w-full pl-12 pr-12 py-3.5 bg-gray-50 border border-gray-100 rounded-[1.25rem] focus:bg-white focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all text-gray-900 font-semibold placeholder:text-gray-400 placeholder:font-medium disabled:opacity-50"
    />
    {type === 'password' && onTogglePassword && (
      <button
        type="button"
        onClick={onTogglePassword}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
      >
        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    )}
  </div>
);

interface Props {
  onLogin: (username: string) => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

export const Login: React.FC<Props> = ({ onLogin, lang, setLang }) => {
  const [view, setView] = useState<'login' | 'signup' | 'forgot'>('login');
  const [forgotStep, setForgotStep] = useState<'verify' | 'reset'>('verify');
  const [showPassword, setShowPassword] = useState(false);
  const [biometricSupported, setBiometricSupported] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isResetSuccess, setIsResetSuccess] = useState(false);
  const [generatedId, setGeneratedId] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    userId: '',
    password: '',
    confirmPassword: '',
    mobile: '',
    email: ''
  });
  const [error, setError] = useState('');

  const t = translations[lang];

  useEffect(() => {
    const checkSupport = async () => {
      const isSupported = !!(window.PublicKeyCredential && 
        await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable());
      setBiometricSupported(isSupported);
      setBiometricEnabled(StorageService.getBiometricEnabled());
    };
    checkSupport();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError('');
  };

  const handleBiometricLogin = async () => {
    const savedUser = StorageService.getSavedUser();
    if (!savedUser) return;

    setIsAuthenticating(true);
    try {
      onLogin(savedUser);
    } catch (err) {
      setError("Biometric authentication failed");
    } finally {
      setIsAuthenticating(false);
    }
  };

  const generateUserId = (name: string) => {
    const cleanName = name.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    return `${cleanName || 'user'}_${randomSuffix}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (view === 'signup') {
      if (formData.password !== formData.confirmPassword) {
        setError(t.passwordMismatch);
        return;
      }
      
      setIsAuthenticating(true);
      const newId = generateUserId(formData.username);
      
      const result = await SupabaseService.registerUser({
        userId: newId,
        fullName: formData.username,
        mobile: formData.mobile,
        email: formData.email,
        password: formData.password
      });

      if (result.error) {
        setError(result.error);
      } else {
        setGeneratedId(newId);
        setIsSuccess(true);
      }
      setIsAuthenticating(false);
    } else if (view === 'login') {
      if (!formData.userId || !formData.password) {
        setError(lang === 'ta' ? 'பயனர் ஐடி மற்றும் கடவுச்சொல் தேவை' : 'User ID and password are required');
        return;
      }

      setIsAuthenticating(true);
      const result = await SupabaseService.loginUser(formData.userId, formData.password);
      
      if (result.error) {
        setError(result.error);
      } else if (result.data) {
        onLogin(result.data);
      }
      setIsAuthenticating(false);
    } else if (view === 'forgot') {
      if (forgotStep === 'verify') {
        if (!formData.userId || !formData.mobile) {
          setError(t.invalidDetails);
          return;
        }
        setIsAuthenticating(true);
        const result = await SupabaseService.verifyIdentity(formData.userId, formData.mobile);
        if (result.data) {
          setForgotStep('reset');
          setError('');
        } else {
          setError(t.invalidDetails);
        }
        setIsAuthenticating(false);
      } else {
        if (formData.password !== formData.confirmPassword) {
          setError(t.passwordMismatch);
          return;
        }
        setIsAuthenticating(true);
        const result = await SupabaseService.updatePassword(formData.userId, formData.password);
        if (result.data) {
          setIsResetSuccess(true);
          setTimeout(() => {
            setView('login');
            setIsResetSuccess(false);
            setForgotStep('verify');
            setFormData(prev => ({ ...prev, password: '', confirmPassword: '' }));
          }, 2000);
        } else {
          setError(result.error || 'Failed to update password');
        }
        setIsAuthenticating(false);
      }
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-green-100 text-green-600 rounded-[2rem] flex items-center justify-center mb-8 animate-in zoom-in duration-500">
          <CheckCircle2 size={48} strokeWidth={2.5} />
        </div>
        <h2 className="text-3xl font-black text-gray-900 mb-2">{lang === 'ta' ? 'வெற்றி!' : 'Registration Success!'}</h2>
        <p className="text-gray-500 font-medium mb-8 max-w-xs mx-auto">
          {lang === 'ta' ? 'உங்கள் கணக்கு உருவாக்கப்பட்டது. உங்கள் பயனர் ஐடியை குறித்துக் கொள்ளவும்:' : 'Your account has been created. Please note your User ID:'}
        </p>
        
        <div className="bg-gray-50 p-6 rounded-[1.5rem] border border-gray-100 mb-10 w-full max-w-xs group relative">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Your Unique User ID</p>
          <div className="flex items-center justify-center gap-3">
            <span className="text-2xl font-black text-blue-600 tracking-tight">{generatedId}</span>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(generatedId);
                alert(lang === 'ta' ? 'நகலெடுக்கப்பட்டது!' : 'Copied to clipboard!');
              }}
              className="p-2 bg-white text-gray-400 hover:text-blue-600 rounded-lg shadow-sm border border-gray-100"
            >
              <Copy size={16} />
            </button>
          </div>
        </div>

        <button
          onClick={() => onLogin(generatedId)}
          className="w-full max-w-xs py-5 bg-gray-900 text-white font-black rounded-[1.5rem] hover:bg-black active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl shadow-gray-200 group"
        >
          <span className="tracking-wide">{lang === 'ta' ? 'டாஷ்போர்டுக்குச் செல்லவும்' : 'Continue to Dashboard'}</span>
          <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white relative flex flex-col items-center justify-center p-6 sm:p-10 overflow-x-hidden">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[40%] bg-blue-50 rounded-full blur-[100px] opacity-60"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[40%] bg-indigo-50 rounded-full blur-[100px] opacity-60"></div>
      </div>

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="text-center space-y-4 animate-in fade-in zoom-in-95 duration-700">
          <div className="relative inline-block">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[1.5rem] flex items-center justify-center mx-auto shadow-2xl shadow-blue-200 relative z-10">
              <RefreshCw className={`text-white ${isAuthenticating ? 'animate-spin' : 'animate-[spin_8s_linear_infinite]'}`} size={32} />
            </div>
            {!isAuthenticating && (
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-lg flex items-center justify-center text-white shadow-lg z-20 animate-bounce">
                <Sparkles size={14} fill="currentColor" />
              </div>
            )}
          </div>
          <div>
            <h1 className="text-3xl font-black text-gray-900 tracking-tight">{t.appTitle}</h1>
            <p className="text-gray-500 mt-1 font-bold uppercase tracking-[0.2em] text-[10px]">
              {view === 'signup' ? t.signUp : view === 'forgot' ? t.forgotPassword : t.login}
            </p>
          </div>
        </div>

        <div className="bg-white/40 backdrop-blur-xl p-2 rounded-[2.5rem] shadow-2xl shadow-black/[0.02] border border-white/60">
          <form onSubmit={handleSubmit} className="p-4 space-y-3">
            {isResetSuccess ? (
              <div className="flex flex-col items-center py-8 animate-in zoom-in duration-300">
                <div className="w-16 h-16 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 size={32} />
                </div>
                <p className="font-bold text-green-600">{t.passwordResetSuccess}</p>
              </div>
            ) : view === 'forgot' ? (
              <div className="space-y-3">
                <p className="text-xs text-gray-500 font-medium px-2 mb-4">
                  {forgotStep === 'verify' ? t.verifyIdentityText : t.identityVerified}
                </p>
                
                {forgotStep === 'verify' ? (
                  <>
                    <InputField 
                      name="userId" 
                      type="text" 
                      placeholder={t.userId} 
                      icon={Hash} 
                      value={formData.userId}
                      onChange={handleInputChange}
                      disabled={isAuthenticating}
                    />
                    <InputField 
                      name="mobile" 
                      type="tel" 
                      placeholder={t.mobileNumber} 
                      icon={Smartphone} 
                      value={formData.mobile}
                      onChange={handleInputChange}
                      disabled={isAuthenticating}
                    />
                  </>
                ) : (
                  <>
                    <InputField 
                      name="password" 
                      type="password" 
                      placeholder={t.newPassword} 
                      icon={Lock} 
                      value={formData.password}
                      onChange={handleInputChange}
                      showPassword={showPassword}
                      onTogglePassword={() => setShowPassword(!showPassword)}
                      disabled={isAuthenticating}
                    />
                    <InputField 
                      name="confirmPassword" 
                      type="password" 
                      placeholder={t.confirmPassword} 
                      icon={Lock} 
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      showPassword={showPassword}
                      onTogglePassword={() => setShowPassword(!showPassword)}
                      disabled={isAuthenticating}
                    />
                  </>
                )}
              </div>
            ) : view === 'signup' ? (
              <>
                <InputField 
                  name="username" 
                  type="text" 
                  placeholder={t.username} 
                  icon={User} 
                  value={formData.username}
                  onChange={handleInputChange}
                  disabled={isAuthenticating}
                />
                <InputField 
                  name="mobile" 
                  type="tel" 
                  placeholder={t.mobileNumber} 
                  icon={Smartphone} 
                  value={formData.mobile}
                  onChange={handleInputChange}
                  disabled={isAuthenticating}
                />
                <InputField 
                  name="email" 
                  type="email" 
                  placeholder={t.emailId} 
                  icon={Mail} 
                  value={formData.email}
                  onChange={handleInputChange}
                  disabled={isAuthenticating}
                />
                <InputField 
                  name="password" 
                  type="password" 
                  placeholder={t.password} 
                  icon={Lock} 
                  value={formData.password}
                  onChange={handleInputChange}
                  showPassword={showPassword}
                  onTogglePassword={() => setShowPassword(!showPassword)}
                  disabled={isAuthenticating}
                />
                <InputField 
                  name="confirmPassword" 
                  type="password" 
                  placeholder={t.confirmPassword} 
                  icon={Lock} 
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  showPassword={showPassword}
                  onTogglePassword={() => setShowPassword(!showPassword)}
                  disabled={isAuthenticating}
                />
              </>
            ) : (
              <>
                <InputField 
                  name="userId" 
                  type="text" 
                  placeholder={t.userId} 
                  icon={Hash} 
                  value={formData.userId}
                  onChange={handleInputChange}
                  disabled={isAuthenticating}
                />
                <InputField 
                  name="password" 
                  type="password" 
                  placeholder={t.password} 
                  icon={Lock} 
                  value={formData.password}
                  onChange={handleInputChange}
                  showPassword={showPassword}
                  onTogglePassword={() => setShowPassword(!showPassword)}
                  disabled={isAuthenticating}
                />
                <div className="flex justify-end px-2">
                  <button 
                    type="button"
                    onClick={() => setView('forgot')}
                    className="text-[10px] font-black text-blue-600 hover:underline uppercase tracking-widest"
                  >
                    {t.forgotPassword}
                  </button>
                </div>
              </>
            )}

            {error && !isResetSuccess && (
              <div className="flex items-center gap-2 text-red-500 text-[10px] font-black bg-red-50 p-3 rounded-xl animate-shake">
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                {error}
              </div>
            )}

            <div className="flex flex-col gap-3 mt-6">
              {!isResetSuccess && (
                <button
                  type="submit"
                  disabled={isAuthenticating}
                  className="w-full py-4 bg-gray-900 text-white font-black rounded-[1.25rem] transition-all shadow-xl shadow-gray-200 flex items-center justify-center gap-3 group hover:bg-black active:scale-[0.98] disabled:opacity-70 disabled:active:scale-100"
                >
                  {isAuthenticating ? (
                    <Loader2 size={24} className="animate-spin" />
                  ) : (
                    <>
                      <span className="tracking-wide">
                        {view === 'signup' ? t.signUp : view === 'forgot' ? (forgotStep === 'verify' ? t.verifyDetails : t.resetPassword) : t.login}
                      </span>
                      <div className="w-7 h-7 bg-white/10 rounded-lg flex items-center justify-center group-hover:bg-white/20 transition-colors">
                        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                      </div>
                    </>
                  )}
                </button>
              )}

              {view === 'login' && biometricEnabled && biometricSupported && (
                <button
                  type="button"
                  onClick={handleBiometricLogin}
                  disabled={isAuthenticating}
                  className="w-full py-4 bg-white text-gray-900 font-black rounded-[1.25rem] hover:bg-gray-50 active:scale-[0.98] transition-all border-2 border-gray-100 flex items-center justify-center gap-3 disabled:opacity-70 disabled:active:scale-100 shadow-sm"
                >
                  <div className="w-8 h-8 bg-blue-50 rounded-xl flex items-center justify-center">
                    <Fingerprint size={20} className="text-blue-600" />
                  </div>
                  <span className="text-sm tracking-wide">{t.useBiometric}</span>
                </button>
              )}
            </div>
          </form>
        </div>

        <div className="text-center space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          <button
            onClick={() => {
              if (view === 'forgot') setView('login');
              else setView(view === 'signup' ? 'login' : 'signup');
              setError('');
              setFormData({ 
                username: '', 
                userId: '', 
                password: '', 
                confirmPassword: '', 
                mobile: '', 
                email: '' 
              });
              setForgotStep('verify');
            }}
            className="group inline-flex items-center gap-2 text-xs font-black text-blue-600 hover:text-blue-700 transition-all active:scale-95"
          >
            {view === 'signup' ? (
              <>
                <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
                {t.alreadyHaveAccount}
              </>
            ) : view === 'forgot' ? (
              <>
                <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
                {t.backToLogin}
              </>
            ) : (
              <>
                {t.dontHaveAccount}
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>

          <div className="flex justify-center">
            <div className="inline-flex bg-gray-100 p-1 rounded-full border border-gray-200/50">
              <button 
                onClick={() => setLang('en')} 
                disabled={isAuthenticating}
                className={`px-5 py-2 rounded-full text-[9px] font-black tracking-[0.2em] uppercase transition-all ${lang === 'en' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
              >
                ENGLISH
              </button>
              <button 
                onClick={() => setLang('ta')} 
                disabled={isAuthenticating}
                className={`px-5 py-2 rounded-full text-[9px] font-black tracking-[0.2em] uppercase transition-all ${lang === 'ta' ? 'bg-white text-blue-600 shadow-sm font-tamil' : 'text-gray-400 hover:text-gray-600'}`}
              >
                தமிழ்
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
