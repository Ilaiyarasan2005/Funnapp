
import React, { useMemo, useState, useEffect } from 'react';
import { Transaction, TransactionType, Language, TimeRange } from '../types';
import { translations } from '../translations';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, AreaChart, Area } from 'recharts';
import { TrendingUp, TrendingDown, Wallet, LayoutGrid, Calendar } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  lang: Language;
  onExportClick: () => void;
}

/**
 * Utility component to ensure charts have a stable parent with explicit dimensions.
 * It delays rendering until the layout has settled to prevent "width(-1)" errors.
 */
const StableChartContainer: React.FC<{ children: React.ReactNode; height: number }> = ({ children, height }) => {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Small delay to let animations settle and parent dimensions finalize
    const timer = setTimeout(() => setIsReady(true), 150);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div 
      className="w-full relative overflow-hidden" 
      style={{ height: `${height}px`, minHeight: `${height}px` }}
    >
      {isReady ? children : (
        <div className="w-full h-full bg-gray-50/50 animate-pulse rounded-3xl flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-blue-100 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
};

export const Dashboard: React.FC<Props> = ({ transactions, lang, onExportClick }) => {
  const t = translations[lang];
  const [range, setRange] = useState<TimeRange>(TimeRange.DAILY);

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const summaryData = useMemo(() => {
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const filtered = transactions.filter(tr => {
      const trDate = new Date(tr.date);
      if (range === TimeRange.DAILY) {
        return tr.date === todayStr;
      } else if (range === TimeRange.MONTHLY) {
        return trDate.getMonth() === currentMonth && trDate.getFullYear() === currentYear;
      } else if (range === TimeRange.YEARLY) {
        return trDate.getFullYear() === currentYear;
      }
      return true;
    });

    const income = filtered
      .filter(tr => tr.type === TransactionType.INCOME)
      .reduce((sum, tr) => sum + tr.amount, 0);
    const expense = filtered
      .filter(tr => tr.type === TransactionType.EXPENSE)
      .reduce((sum, tr) => sum + tr.amount, 0);
    
    return { income, expense, balance: income - expense, count: filtered.length };
  }, [transactions, range, todayStr]);

  const categoryData = useMemo(() => {
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const categories: Record<string, number> = {};

    transactions.filter(tr => {
      const trDate = new Date(tr.date);
      if (range === TimeRange.DAILY) return tr.date === todayStr;
      if (range === TimeRange.MONTHLY) return trDate.getMonth() === currentMonth && trDate.getFullYear() === currentYear;
      if (range === TimeRange.YEARLY) return trDate.getFullYear() === currentYear;
      return true;
    })
    .filter(tr => tr.type === TransactionType.EXPENSE)
    .forEach(tr => {
      categories[tr.category] = (categories[tr.category] || 0) + tr.amount;
    });

    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [transactions, range, todayStr]);

  const trendData = useMemo(() => {
    const trends: Record<string, { income: number; expense: number; balance: number; sortKey: string }> = {};
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    if (range === TimeRange.DAILY) {
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const label = d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' });
        const sortKey = d.toISOString().split('T')[0];
        trends[label] = { income: 0, expense: 0, balance: 0, sortKey };
      }
    }

    const chartFiltered = transactions.filter(tr => {
      const trDate = new Date(tr.date);
      if (range === TimeRange.DAILY) {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(now.getDate() - 6);
        sevenDaysAgo.setHours(0, 0, 0, 0);
        return trDate >= sevenDaysAgo && trDate <= now;
      } else if (range === TimeRange.MONTHLY) {
        return trDate.getMonth() === currentMonth && trDate.getFullYear() === currentYear;
      } else if (range === TimeRange.YEARLY) {
        return trDate.getFullYear() === currentYear;
      }
      return true;
    });

    chartFiltered.forEach(tr => {
      const d = new Date(tr.date);
      let label = '';
      let sortKey = tr.date;

      if (range === TimeRange.DAILY) {
        label = d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' });
      } else if (range === TimeRange.MONTHLY) {
        label = d.getDate().toString();
      } else if (range === TimeRange.YEARLY) {
        label = d.toLocaleString('default', { month: 'short' });
        sortKey = d.getFullYear() + '-' + (d.getMonth() + 1).toString().padStart(2, '0');
      }

      if (!trends[label]) trends[label] = { income: 0, expense: 0, balance: 0, sortKey };
      if (tr.type === TransactionType.INCOME) trends[label].income += tr.amount;
      else trends[label].expense += tr.amount;
      
      trends[label].balance = trends[label].income - trends[label].expense;
    });

    return Object.entries(trends)
      .map(([name, vals]) => ({ name, ...vals }))
      .sort((a, b) => a.sortKey.localeCompare(b.sortKey));
  }, [transactions, range]);

  const COLORS = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#6366F1', '#EC4899', '#8B5CF6'];

  const chartTitle = range === TimeRange.DAILY ? (lang === 'ta' ? 'கடந்த 7 நாட்கள் போக்கு' : 'Last 7 Days Trend') : 
                     range === TimeRange.MONTHLY ? (lang === 'ta' ? 'மாதாந்திர போக்கு' : 'Monthly Trend') : 
                     (lang === 'ta' ? 'ஆண்டு போக்கு' : "Yearly Trend");

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-100 shadow-2xl rounded-2xl">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{label}</p>
          <div className="space-y-1.5">
            {payload.map((entry: any, index: number) => (
              <div key={index} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }}></div>
                  <span className="text-xs font-bold text-gray-600">{entry.name}:</span>
                </div>
                <span className="text-xs font-black text-gray-900">₹{entry.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 w-full min-w-0">
      {/* Time Range Selector */}
      <div className="flex items-center justify-between gap-4 overflow-x-auto pb-2 scrollbar-hide">
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-gray-100 w-fit shrink-0">
          <button onClick={() => setRange(TimeRange.DAILY)} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${range === TimeRange.DAILY ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'}`}>
            {t.daily}
          </button>
          <button onClick={() => setRange(TimeRange.MONTHLY)} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${range === TimeRange.MONTHLY ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'}`}>
            {t.monthly}
          </button>
          <button onClick={() => setRange(TimeRange.YEARLY)} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${range === TimeRange.YEARLY ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-gray-500 hover:bg-gray-50'}`}>
            {t.yearly}
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:border-blue-200 transition-colors">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Wallet size={24} />
          </div>
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">{t.totalBalance}</p>
          <h3 className="text-2xl font-black mt-1 text-gray-900">₹{summaryData.balance.toLocaleString()}</h3>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:border-green-200 transition-colors">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <TrendingUp size={24} />
          </div>
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">{t.totalIncome}</p>
          <h3 className="text-2xl font-black mt-1 text-green-600">₹{summaryData.income.toLocaleString()}</h3>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:border-red-200 transition-colors">
          <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <TrendingDown size={24} />
          </div>
          <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">{t.totalExpense}</p>
          <h3 className="text-2xl font-black mt-1 text-red-600">₹{summaryData.expense.toLocaleString()}</h3>
        </div>
      </div>

      {/* Trend Area Chart */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 overflow-hidden w-full min-w-0">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Calendar size={18} />
            </div>
            <h3 className="font-black text-gray-800 tracking-tight">{chartTitle}</h3>
          </div>
        </div>
        
        <StableChartContainer height={300}>
          {trendData.length > 0 ? (
            <ResponsiveContainer width="99%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="#f3f4f6" />
                <XAxis 
                  dataKey="name" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  stroke="#94a3b8" 
                  dy={10} 
                  fontWeight={600}
                />
                <YAxis 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  stroke="#94a3b8" 
                  tickFormatter={(val) => `₹${val >= 1000 ? (val/1000).toFixed(1) + 'k' : val}`}
                />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#e5e7eb', strokeWidth: 1 }} />
                <Area 
                  type="monotone" 
                  name={t.income}
                  dataKey="income" 
                  stroke="#10B981" 
                  fillOpacity={1} 
                  fill="url(#colorIncome)" 
                  strokeWidth={4} 
                  activeDot={{ r: 6, stroke: '#fff', strokeWidth: 3 }}
                  dot={{ r: 3, fill: '#10B981', strokeWidth: 2, stroke: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  name={t.expense}
                  dataKey="expense" 
                  stroke="#EF4444" 
                  fillOpacity={1} 
                  fill="url(#colorExpense)" 
                  strokeWidth={4} 
                  activeDot={{ r: 6, stroke: '#fff', strokeWidth: 3 }}
                  dot={{ r: 3, fill: '#EF4444', strokeWidth: 2, stroke: '#fff' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-400 font-medium italic">
              {t.noTransactions}
            </div>
          )}
        </StableChartContainer>
      </div>

      {/* Category Reports Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-4 w-full min-w-0">
        {/* Category Bar Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 w-full min-w-0">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <LayoutGrid size={18} />
            </div>
            <h3 className="font-black text-gray-800 tracking-tight">{t.category} {t.report}</h3>
          </div>
          
          <StableChartContainer height={260}>
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="99%" height="100%">
                <BarChart data={categoryData} layout="vertical" margin={{ left: -10, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" fontSize={11} tickLine={false} axisLine={false} width={80} stroke="#64748b" fontWeight={600} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none' }} />
                  <Bar dataKey="value" radius={[0, 10, 10, 0]} barSize={16}>
                    {categoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400 font-medium italic">
                {t.noTransactions}
              </div>
            )}
          </StableChartContainer>
        </div>

        {/* Expense Share Pie Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 w-full min-w-0">
          <div className="flex items-center gap-3 mb-6">
             <div className="p-2 bg-orange-50 text-orange-600 rounded-xl">
              <TrendingDown size={18} />
            </div>
            <h3 className="font-black text-gray-800 tracking-tight">{t.expense} Share</h3>
          </div>
          
          <StableChartContainer height={260}>
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="99%" height="100%">
                <PieChart>
                  <Pie data={categoryData} innerRadius={60} outerRadius={80} paddingAngle={8} dataKey="value" stroke="none">
                    {categoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400 font-medium italic">
                {t.noTransactions}
              </div>
            )}
          </StableChartContainer>
        </div>
      </div>
    </div>
  );
};
