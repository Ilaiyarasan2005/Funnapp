
import React, { useState, useRef, useEffect } from 'react';
import { Transaction, ChatMessage, Language } from '../types';
import { translations } from '../translations';
import { chatWithAI } from '../services/gemini';
import { Send, Sparkles, User, Bot, Loader2, MessageSquare } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  lang: Language;
}

export const AIAssistant: React.FC<Props> = ({ transactions, lang }) => {
  const t = translations[lang];
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    const response = await chatWithAI(input, transactions, messages, lang);

    const aiMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, aiMessage]);
    setIsTyping(false);
  };

  const quickQuestions = [
    lang === 'ta' ? 'இன்று நான் எவ்வளவு செலவு செய்தேன்?' : "How much did I spend today?",
    lang === 'ta' ? 'எனது அதிக செலவு வகை எது?' : "Which category is my highest?",
    lang === 'ta' ? 'எனது பட்ஜெட் ஆலோசனை என்ன?' : "What is my budget advice?",
    lang === 'ta' ? 'கடந்த வாரம் சுருக்கம் தேவை' : "Summary for last week"
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 scrollbar-hide">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center text-center py-12 space-y-6">
            <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-[2rem] flex items-center justify-center shadow-xl shadow-blue-100 rotate-3">
              <Bot size={48} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-gray-900 mb-2">{t.aiAssistant}</h3>
              <p className="text-gray-500 text-sm max-w-xs font-medium leading-relaxed">
                {lang === 'ta' ? 'உங்கள் நிதியைப் பற்றி என்னிடம் எதையும் கேளுங்கள். நான் உங்கள் தரவை பகுப்பாய்வு செய்து பதிலளிப்பேன்.' : 'Ask me anything about your finances. I can analyze your spending patterns and give insights.'}
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-2 w-full max-w-xs">
              {quickQuestions.map((q, i) => (
                <button 
                  key={i}
                  onClick={() => { setInput(q); handleSend(); }}
                  className="px-4 py-3 bg-white border border-gray-100 rounded-2xl text-xs font-bold text-gray-600 hover:border-blue-300 hover:text-blue-600 hover:bg-blue-50 transition-all text-left shadow-sm"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 shrink-0 rounded-xl flex items-center justify-center shadow-sm ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white text-blue-600 border border-blue-50'}`}>
                {msg.role === 'user' ? <User size={16} /> : <Sparkles size={16} />}
              </div>
              <div className={`p-4 rounded-2xl text-sm font-medium leading-relaxed shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start animate-in fade-in duration-300">
            <div className="flex gap-3 max-w-[85%]">
              <div className="w-8 h-8 shrink-0 rounded-xl bg-white border border-blue-50 text-blue-600 flex items-center justify-center shadow-sm">
                <Loader2 size={16} className="animate-spin" />
              </div>
              <div className="p-4 bg-white border border-gray-100 text-gray-400 text-xs font-bold italic rounded-2xl rounded-tl-none flex items-center gap-2">
                {t.aiThinking}
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-gray-100 rounded-t-[2rem] shadow-[0_-4px_20px_rgba(0,0,0,0.02)]">
        <form onSubmit={handleSend} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t.aiChatPlaceholder}
            className="w-full pl-6 pr-14 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all font-semibold text-gray-900 placeholder:text-gray-400 placeholder:font-medium"
          />
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center hover:bg-blue-700 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 shadow-lg shadow-blue-100"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};
