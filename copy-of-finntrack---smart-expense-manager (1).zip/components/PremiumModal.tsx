
import React from 'react';
import { X, Crown, FileText, Share2, Cloud } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface Props {
  onClose: () => void;
  lang: Language;
}

export const PremiumModal: React.FC<Props> = ({ onClose, lang }) => {
  const t = translations[lang];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl overflow-hidden relative">
        {/* Background Gradient Decorative Element */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/10 rounded-full -ml-16 -mb-16 blur-3xl"></div>

        <button 
          onClick={onClose} 
          className="absolute top-6 right-6 p-2 bg-gray-50 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X size={20} className="text-gray-500" />
        </button>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-tr from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-orange-100 rotate-12">
            <Crown size={32} className="text-white" />
          </div>
          <h2 className="text-2xl font-black text-gray-900">{t.premiumFeature}</h2>
          <p className="text-gray-500 mt-2 text-sm font-medium">{t.premiumRequired}</p>
        </div>

        <div className="space-y-4 mb-8">
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-blue-600 shadow-sm">
              <FileText size={20} />
            </div>
            <div>
              <p className="font-bold text-gray-800 text-sm">PDF & Excel Reports</p>
              <p className="text-xs text-gray-500">Professional detailed exports</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-purple-600 shadow-sm">
              <Cloud size={20} />
            </div>
            <div>
              <p className="font-bold text-gray-800 text-sm">Unlimited Cloud Sync</p>
              <p className="text-xs text-gray-500">Access data on any device</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-green-600 shadow-sm">
              <Share2 size={20} />
            </div>
            <div>
              <p className="font-bold text-gray-800 text-sm">Shared Business Accounts</p>
              <p className="text-xs text-gray-500">Collaborate with your team</p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-gray-800 active:scale-95 transition-all shadow-xl shadow-gray-200"
        >
          {t.upgradeNow}
        </button>
      </div>
    </div>
  );
};
