
import React, { useState } from 'react';
import { Transaction, TransactionType, Language } from '../types';
import { translations } from '../translations';
import { 
  Trash2, 
  ShoppingBag, 
  Utensils, 
  Bus, 
  Home, 
  Plus, 
  Activity, 
  Book, 
  FileText, 
  HelpCircle, 
  Info,
  ChevronDown,
  ChevronUp,
  Pencil,
  Sparkles,
  History as HistoryIcon
} from 'lucide-react';

interface Props {
  transactions: Transaction[];
  onDelete: (id: string) => void;
  onEdit: (transaction: Transaction) => void;
  lang: Language;
  onExportClick: () => void;
}

const CategoryIcon: React.FC<{ category: string }> = ({ category }) => {
  const iconProps = { size: 18 };
  const cat = category.toLowerCase();
  
  switch (cat) {
    case 'food': return <Utensils {...iconProps} />;
    case 'transport': return <Bus {...iconProps} />;
    case 'shopping': return <ShoppingBag {...iconProps} />;
    case 'rent': return <Home {...iconProps} />;
    case 'health': return <Activity {...iconProps} />;
    case 'education': return <Book {...iconProps} />;
    case 'bills': return <FileText {...iconProps} />;
    default: return <HelpCircle {...iconProps} />;
  }
};

export const History: React.FC<Props> = ({ transactions, onDelete, onEdit, lang, onExportClick }) => {
  const t = translations[lang];
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Sorting: Newest first by date AND time
  const sortedTransactions = [...transactions].sort((a, b) => {
    const dateTimeA = `${a.date} ${a.time}`;
    const dateTimeB = `${b.date} ${b.time}`;
    return dateTimeB.localeCompare(dateTimeA);
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-500 pb-4">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-xl font-black text-gray-800 tracking-tight">{t.history}</h3>
          <span className="px-3 py-1 bg-gray-100 text-gray-500 text-[10px] font-black rounded-full uppercase tracking-widest">
            {transactions.length} {t.transactions}
          </span>
        </div>

        {transactions.length > 0 && (
          <div className="px-2">
            <button 
              onClick={onExportClick} 
              className="w-full group flex items-center justify-center gap-3 px-6 py-4 bg-white border-2 border-blue-50 text-blue-600 rounded-2xl font-black text-xs uppercase tracking-widest shadow-sm hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all active:scale-[0.98]"
            >
              <FileText size={20} className="transition-transform group-hover:scale-110" />
              {t.exportTransactions}
              <Sparkles size={14} className="text-blue-300 transition-colors group-hover:text-white" />
            </button>
          </div>
        )}
      </div>

      {transactions.length === 0 ? (
        <div className="bg-white rounded-[2.5rem] border-2 border-dashed border-gray-100 py-20 flex flex-col items-center justify-center text-center px-8">
          <div className="w-20 h-20 bg-gray-50 text-gray-200 rounded-full flex items-center justify-center mb-6">
            <HistoryIcon size={40} />
          </div>
          <h4 className="text-gray-400 font-black uppercase tracking-widest text-xs mb-2">Empty Records</h4>
          <p className="text-gray-300 text-sm font-medium italic">{t.noTransactions}</p>
        </div>
      ) : (
        <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
          <div className="divide-y divide-gray-100">
            {sortedTransactions.map((tr) => {
              const isExpanded = expandedId === tr.id;
              return (
                <div key={tr.id} className="group transition-all">
                  <div onClick={() => setExpandedId(isExpanded ? null : tr.id)} className={`p-5 flex items-center justify-between hover:bg-gray-50/50 transition-colors cursor-pointer ${isExpanded ? 'bg-gray-50' : ''}`}>
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${isExpanded ? 'scale-110 shadow-lg' : ''} ${tr.type === TransactionType.INCOME ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                        <CategoryIcon category={tr.category} />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-800">{tr.category}</h4>
                        <div className="flex items-center gap-2">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{new Date(tr.date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <span className={`font-black text-lg ${tr.type === TransactionType.INCOME ? 'text-green-600' : 'text-red-600'}`}>
                          {tr.type === TransactionType.INCOME ? '+' : '-'} ₹{tr.amount.toLocaleString()}
                        </span>
                        <div className="flex items-center justify-end gap-1 mt-0.5">
                          {isExpanded ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
                        </div>
                      </div>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="px-5 pb-5 pt-0 animate-in slide-in-from-top-2 duration-300">
                      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-inner space-y-3">
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5 p-1.5 bg-gray-50 text-gray-400 rounded-lg"><Info size={14} /></div>
                          <div className="flex-1">
                            <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{t.note}</p>
                            <p className="text-sm text-gray-600 leading-relaxed font-medium">{tr.note || <span className="italic text-gray-300">No details provided.</span>}</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-50">
                          <button onClick={(e) => { e.stopPropagation(); onEdit(tr); }} className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-all active:scale-95">
                            <Pencil size={14} />
                            <span className="text-[10px] font-black uppercase tracking-widest">{t.edit}</span>
                          </button>
                          <button onClick={(e) => { e.stopPropagation(); onDelete(tr.id); }} className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-all active:scale-95">
                            <Trash2 size={14} />
                            <span className="text-[10px] font-black uppercase tracking-widest">{t.delete}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
