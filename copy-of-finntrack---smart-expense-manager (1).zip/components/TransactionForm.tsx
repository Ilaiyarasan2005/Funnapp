
import React, { useState } from 'react';
import { Transaction, TransactionType, Language } from '../types';
import { translations } from '../translations';
import { X, Save, Plus, Minus, Calendar as CalendarIcon } from 'lucide-react';

interface Props {
  onSave: (transaction: Omit<Transaction, 'id'>, id?: string) => void;
  onCancel: () => void;
  lang: Language;
  initialData?: Transaction;
}

const CATEGORIES = ['Food', 'Transport', 'Rent', 'Shopping', 'Health', 'Education', 'Bills', 'Other'];

export const TransactionForm: React.FC<Props> = ({ onSave, onCancel, lang, initialData }) => {
  const t = translations[lang];
  const [amount, setAmount] = useState(initialData ? initialData.amount.toString() : '');
  const [type, setType] = useState<TransactionType>(initialData ? initialData.type : TransactionType.EXPENSE);
  const [category, setCategory] = useState(initialData ? initialData.category : CATEGORIES[0]);
  const [date, setDate] = useState(initialData ? initialData.date : new Date().toISOString().split('T')[0]);
  // We keep time in state to pass it to the save function, but we hide it from the user.
  const [time] = useState(initialData ? initialData.time : new Date().toTimeString().split(' ')[0].substring(0, 5));
  const [note, setNote] = useState(initialData ? initialData.note : '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount))) return;

    onSave({
      amount: Number(amount),
      type,
      category,
      date,
      time,
      note
    }, initialData?.id);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-500 via-purple-500 to-indigo-500"></div>
        
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">{initialData ? t.edit : t.addTransaction}</h2>
          <button onClick={onCancel} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X size={24} className="text-gray-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex gap-2 p-1.5 bg-gray-100 rounded-2xl border border-gray-200/50">
            <button
              type="button"
              onClick={() => setType(TransactionType.EXPENSE)}
              className={`flex-1 py-3 rounded-xl font-black transition-all flex items-center justify-center gap-2 ${type === TransactionType.EXPENSE ? 'bg-white text-red-600 shadow-sm' : 'text-gray-400'}`}
            >
              <Minus size={18} />
              <span className="text-xs uppercase tracking-widest">{t.expense}</span>
            </button>
            <button
              type="button"
              onClick={() => setType(TransactionType.INCOME)}
              className={`flex-1 py-3 rounded-xl font-black transition-all flex items-center justify-center gap-2 ${type === TransactionType.INCOME ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'}`}
            >
              <Plus size={18} />
              <span className="text-xs uppercase tracking-widest">{t.income}</span>
            </button>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.amount}</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-gray-400 text-xl">₹</span>
              <input
                type="number"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-10 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-4 focus:ring-blue-50 focus:border-blue-500 outline-none text-2xl font-black text-gray-900 transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1 flex items-center gap-1.5">
              <CalendarIcon size={12} /> {t.date}
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:bg-white focus:border-blue-500 outline-none text-sm font-bold text-gray-700 transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.category}</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:bg-white focus:border-blue-500 outline-none text-sm font-bold text-gray-700 appearance-none"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.note}</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:bg-white focus:border-blue-500 outline-none resize-none text-sm font-medium text-gray-700 transition-all"
            />
          </div>

          <button
            type="submit"
            className="w-full py-5 bg-gray-900 text-white font-black rounded-[1.5rem] flex items-center justify-center gap-3 hover:bg-black active:scale-[0.98] transition-all shadow-xl shadow-gray-200 mt-4 group"
          >
            <Save size={20} className="group-hover:scale-110 transition-transform" />
            <span className="tracking-wide text-lg">{t.save}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
