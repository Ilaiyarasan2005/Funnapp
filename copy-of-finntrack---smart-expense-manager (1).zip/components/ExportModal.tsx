import React, { useState, useMemo } from 'react';
import { X, Calendar, Filter, Sparkles, CheckCircle2, History, FileText, ArrowRight } from 'lucide-react';
import { Transaction, TransactionType, Language } from '../types';
import { translations } from '../translations';
import { PdfService } from '../services/pdf';

interface Props {
  transactions: Transaction[];
  onClose: () => void;
  lang: Language;
  userName: string;
}

export const ExportModal: React.FC<Props> = ({ transactions, onClose, lang, userName }) => {
  const t = translations[lang];
  const now = new Date();
  const [startDate, setStartDate] = useState(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0]);
  const [filterType, setFilterType] = useState<'all' | TransactionType>('all');

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tr => {
      const trDate = tr.date;
      return trDate >= startDate && trDate <= endDate && (filterType === 'all' || tr.type === filterType);
    });
  }, [transactions, startDate, endDate, filterType]);

  const applyQuickRange = (range: 'today' | 'week' | 'month' | 'all') => {
    const end = new Date().toISOString().split('T')[0];
    let start = '';
    const d = new Date();
    if (range === 'today') start = end;
    else if (range === 'week') { d.setDate(d.getDate() - 7); start = d.toISOString().split('T')[0]; }
    else if (range === 'month') { d.setDate(1); start = d.toISOString().split('T')[0]; }
    else if (range === 'all' && transactions.length > 0) { start = [...transactions].sort((a,b) => a.date.localeCompare(b.date))[0].date; }
    else start = end;
    setStartDate(start);
    setEndDate(end);
  };

  const handleDownloadPdf = () => {
    if (filteredTransactions.length === 0) { alert(t.noTransactions); return; }
    const doc = PdfService.generateReport(filteredTransactions, {
      userName,
      startDate,
      endDate,
      lang
    });
    doc.save(`FinnTrack_Report_${startDate}_to_${endDate}.pdf`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 z-[70] animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-[3rem] p-8 shadow-2xl relative overflow-hidden border border-gray-100">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-br from-blue-50 via-white to-indigo-50 -z-10"></div>
        
        <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white/80 hover:bg-white rounded-full transition-all shadow-sm border border-gray-100 group">
          <X size={20} className="text-gray-400 group-hover:text-gray-600 group-hover:rotate-90 transition-all duration-300" />
        </button>

        <div className="flex items-center gap-5 mb-10">
          <div className="w-16 h-16 bg-blue-600 text-white rounded-[1.5rem] flex items-center justify-center shadow-xl shadow-blue-100 ring-4 ring-white relative overflow-hidden group">
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            <FileText size={32} className="relative z-10" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight leading-tight">{t.exportTransactions}</h2>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
              <p className="text-[10px] text-blue-600 font-black uppercase tracking-widest">Financial Report Center</p>
            </div>
          </div>
        </div>

        <div className="space-y-8 mb-10">
          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <History size={12} className="text-blue-500" />
              {t.quickRanges}
            </label>
            <div className="flex flex-wrap gap-2">
              {['today', 'week', 'month', 'all'].map(r => (
                <button 
                  key={r} 
                  onClick={() => applyQuickRange(r as any)} 
                  className="px-5 py-2.5 bg-gray-50 hover:bg-blue-600 hover:text-white rounded-xl text-xs font-bold transition-all border border-gray-100 active:scale-95 shadow-sm"
                >
                  {(t as any)[r] || r}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5"><Calendar size={12} />{t.startDate}</label>
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-500 outline-none text-sm font-black text-gray-700 transition-all" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5"><Calendar size={12} />{t.endDate}</label>
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-4 focus:ring-blue-50 focus:border-blue-500 outline-none text-sm font-black text-gray-700 transition-all" />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5"><Filter size={12} />{t.category}</label>
            <div className="flex bg-gray-100 p-1.5 rounded-[1.5rem] border border-gray-200/30">
              <button onClick={() => setFilterType('all')} className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${filterType === 'all' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}>{t.allTypes}</button>
              <button onClick={() => setFilterType(TransactionType.INCOME)} className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${filterType === TransactionType.INCOME ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}>{t.income}</button>
              <button onClick={() => setFilterType(TransactionType.EXPENSE)} className={`flex-1 py-3 rounded-xl text-xs font-black transition-all ${filterType === TransactionType.EXPENSE ? 'bg-white text-red-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}>{t.expense}</button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-center gap-3 py-3 px-5 bg-blue-50 text-blue-600 rounded-2xl transition-all border border-blue-100/50">
            <CheckCircle2 size={16} className="animate-pulse" />
            <span className="text-xs font-black uppercase tracking-widest">
              {t.matchingTransactions.replace('{count}', filteredTransactions.length.toString())}
            </span>
          </div>

          <div className="flex flex-col gap-3">
            <button 
              onClick={handleDownloadPdf} 
              disabled={filteredTransactions.length === 0} 
              className="w-full py-5 bg-blue-600 text-white font-black rounded-[1.5rem] hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-xl shadow-blue-100 group"
            >
              <FileText size={22} />
              <span className="tracking-wide text-lg">Download PDF Report</span>
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform opacity-50" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};