
export enum TransactionType {
  INCOME = 'income',
  EXPENSE = 'expense'
}

export enum TimeRange {
  DAILY = 'daily',
  MONTHLY = 'monthly',
  YEARLY = 'yearly'
}

export interface Transaction {
  id: string;
  amount: number;
  category: string;
  date: string;
  time: string; // Added time field
  note: string;
  type: TransactionType;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export type Language = 'en' | 'ta';

export interface AppState {
  transactions: Transaction[];
  language: Language;
}
